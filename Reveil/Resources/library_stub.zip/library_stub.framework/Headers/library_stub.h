//
//  library_stub.h
//  library-stub
//
//  Created by Mason Rachel on 2023/11/2.
//

#include <stdio.h>

//! Project version number for library_stub.
extern double library_stubVersionNumber;

//! Project version string for library_stub.
extern const unsigned char library_stubVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <library_stub/PublicHeader.h>

